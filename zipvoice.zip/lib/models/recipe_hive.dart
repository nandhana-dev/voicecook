// lib/models/recipe_hive.dart

import 'package:hive/hive.dart';

part 'recipe_hive.g.dart'; // Hive will generate this file

@HiveType(typeId: 0)
class HiveRecipe extends HiveObject {
  @HiveField(0)
  String title;

  @HiveField(1)
  List<String> ingredients;

  @HiveField(2)
  String imagePath; // file path of image stored locally

  @HiveField(3)
  String audioPath; // file path of audio stored locally

  @HiveField(4)
  String creatorId; // changed to match new naming

  HiveRecipe({
    required this.title,
    required this.ingredients,
    required this.imagePath,
    required this.audioPath,
    required this.creatorId,
  });
}
